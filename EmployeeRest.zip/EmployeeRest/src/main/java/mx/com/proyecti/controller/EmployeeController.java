package mx.com.proyecti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import mx.com.proyecti.entity.Employee;
import mx.com.proyecti.service.EmployeeService;

@RestController
// Nos indica que la clase definida se encuentra en la capa controller
// La clase va a fungir como mi servicio REST para definir sus operaciones

// http:localhost:8090/api/...
@CrossOrigin(origins = "*")
@RequestMapping("api")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;

	@GetMapping("/employees")
	// http://localhost:8090/api/employees GET
	List<Employee> getAllEmployees() {
		return employeeService.getAllEmployees();
	}

	@PostMapping("/employees")
	// http://localhost:8090/api/employees POST
	Long insertEmployee(@RequestBody Employee employee) {
		return employeeService.insertEmployee(employee);
	}

	@GetMapping("/employees/{id}")
	// http://localhost:8090/api/employees/{id} GET
	Employee getEmployee(@PathVariable Long id) {
		return employeeService.getEmployee(id);
	}

	@DeleteMapping("/employees/{id}")
	// http://localhost:8090/api/employees/delete POST
	Boolean deleteEmployee(@PathVariable Long id) {
		return employeeService.deleteEmployee(id);
	}

	@PutMapping("/employees")
	// http://localhost:8090/api/employees PUT
	Boolean updateEmployee(@PathVariable Employee employee) {
		return employeeService.updateEmployee(employee);
	}
}
