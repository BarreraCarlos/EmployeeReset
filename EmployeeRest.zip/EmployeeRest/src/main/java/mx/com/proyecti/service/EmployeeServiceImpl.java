package mx.com.proyecti.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import mx.com.proyecti.entity.Employee;
import mx.com.proyecti.repository.EmployeeRepository;

@Service
//Registra a la clase como un componente dentro de la capa de servicios para poder
//ser utilizada por spring
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;

	// @Override
	public List<Employee> getAllEmployees() {
		return employeeRepository.findAll();
	}

	public Employee getEmployee(Long id) {
		return employeeRepository.findOne(id);
	}

	public Long insertEmployee(Employee employee) {
		return employeeRepository.save(employee).getId();
	}

	public Boolean updateEmployee(Employee employee) {
		// TODO Auto-generated method stub
		Employee emp = employeeRepository.getOne(employee.getId());
		if (emp != null) {
			emp.setFirstName(employee.getFirstName());
			emp.setLastName(employee.getLastName());
			emp.setBirthdate(employee.getBirthdate());
			emp.setSalary(employee.getSalary());
			employeeRepository.save(emp);
			return true;
		}
		return false;
	}

	public Boolean deleteEmployee(Long id) {
		employeeRepository.delete(id);
		return true;
	}

}
